# spk-metode-saw-php


Aplikasi Sistem Pedukung Keputusan (SPK) pemilihan supplier dengan menggunakan metode SAW (Simple Additive Weighting) berbasis web, menggunakan bahasa pemograman PHP
