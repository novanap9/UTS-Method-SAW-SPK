
<button class="btn btn-second" id="hidden"><i class="fa fa-list text-white"></i></button>
<ul class="nav">
    <li><a href="./?page=beranda">Beranda</a></li>
    <li><a href="./?page=barang">Barang</a></li>
    <li><a href="./?page=supplier">Supplier</a></li>
    <li><a href="./?page=kriteria">Kriteria</a></li>
    <li><a href="./?page=subkriteria">Sub Kriteria</a></li>
    <li><a href="./?page=bobot">Bobot</a></li>
    <li><a href="./?page=penilaian">Penilaian</a></li>
    <li><a href="./?page=hasil">Hasil</a></li>
    <li><a href="./logout.php" id="out">Keluar</a></li>
</ul>